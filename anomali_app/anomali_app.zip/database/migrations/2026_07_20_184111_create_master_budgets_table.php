<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('master_budgets', function (Blueprint $table) {
            $table->id();
            $table->date('bulan');
            $table->decimal('jumlah_hk', 15, 2)->default(0);
            $table->decimal('budget_bulan_rp', 20, 2)->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('master_budgets');
    }
};
